var num1, num2, num3;

function random(){
	num1 = Math.ceil(Math.random()*20);
	document.getElementById("bio").innerHTML = num1;

	num2 = Math.ceil(Math.random()*20);
	document.getElementById("chem").innerHTML = num2;

	num3 = Math.ceil(Math.random()*20);
	document.getElementById("phys").innerHTML = num3;   
	compare();
}

var highestNum
function compare(){
	highestNum = num1;
	if(highestNum < num2){
		highestNum = num2;
	}
	if(highestNum < num3){
		highestNum = num3;
	}
}

var Subject
function subject(){
	if(highestNum == num1){
		Subject = "Biology";
	}
	else if(highestNum == num2){
		Subject = "Chemistry";
	}
	else if(highestNum == num3){
		Subject = "Physics";
	}
	document.getElementById("noOfPassers").innerHTML = ("The subject with the most number of passers is " + Subject);
}

var firstLetter;
function highestScorer(){
	firstLetter = alphabet[highestNum-1];
	document.getElementById("highestPasser").innerHTML = ("The name of the highest passer for Physics starts with the letter '" + firstLetter + "'");
}

var time;
function timeTaken(){
	time = num2 * num3;
	document.getElementById("timeTook").innerHTML = ("The time it took them to finish the whole physics khub course is " + time + " minutes");
}



const alphabet = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"];
//alert(alphabet[25]);
